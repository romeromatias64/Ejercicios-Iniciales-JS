// 8. Tu lista de compras. Crear un array llamado listaDeCompras con cinco cosas que comprarías en tu próxima visita al supermercado. Muestra cada elemento del array en la consola.

function shopList() {
    const listaDeCompras = ["leche","media docena huevos","arroz","mayonesa","carne","1 kg de papa","bananas"]
    
    console.log(listaDeCompras)
}
